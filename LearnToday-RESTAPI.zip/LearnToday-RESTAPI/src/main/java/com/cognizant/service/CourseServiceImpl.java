package com.cognizant.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.dao.CourseDao;
import com.cognizant.model.Course;

@Service
public class CourseServiceImpl implements CourseService{

	@Autowired
	CourseDao courseDao;
	
	/**
	 * This functions returns values of getAllCourses
	 */
	@Override
	public List<Course> getAllCourses() {
		return courseDao.getAllCourses();
	}

	/**
	 * This funtionc returns the value to getCourseById function with specified id
	 */
	@Override
	public Course getCourseById(int id) {
		return courseDao.getCourseById(id);
	}

}
