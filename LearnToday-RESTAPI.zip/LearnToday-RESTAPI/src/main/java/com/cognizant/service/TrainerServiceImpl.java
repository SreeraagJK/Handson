package com.cognizant.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.dao.TrainerDao;
import com.cognizant.model.Trainer;

@Service
public class TrainerServiceImpl implements TrainerService{

	@Autowired
	TrainerDao trainerdao;
	
	/**
	 * This function returns the value of trainerSignup function
	 */
	@Override
	public boolean trainerSignUp(Trainer t) {
		return trainerdao.trainerSignUp(t);
	}

	/**
	 * This function returns the value of updatePassword function
	 */
	@Override
	public String updatePassword(int id, Trainer t) {
		return trainerdao.updatePassword(id,t);
	}
}
