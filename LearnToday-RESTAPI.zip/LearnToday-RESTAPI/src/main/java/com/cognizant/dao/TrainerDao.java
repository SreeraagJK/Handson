package com.cognizant.dao;

import com.cognizant.model.Trainer;

public interface TrainerDao {

	public boolean trainerSignUp(Trainer t);

	public String updatePassword(int id, Trainer t);  

}
